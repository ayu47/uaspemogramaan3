
<?php
 include_once("koneksi.php");
 include_once("header.php");

?>

<html>
	<head>
	<title>ayu.com</title>
    <link rel="stylesheet" type="text/css" href="bg.css">
	</head>
	<body>
	<h2>ayu.com</h2>
	<br/>
	<a href="inputsatuan.php">TAMBAH SATUAN</a>
	<br/>
	<table border="1">
	<tr>
		<th>Jenis Satuan</th>
		<th>OPSI</th>
	</tr>
	<?php
	include 'koneksi.php';
	$no =1;
	$data = mysqli_query($koneksi,"select * from satuan");
	while($d= mysqli_fetch_array($data)){
		?>
		<tr>
			<td><?php echo $d['nama_satuan']; ?></td>
			<td>
				<a href="editsatuan.php?id_kategori=<?php echo $d['id_satuan']; ?>">EDIT</a>
				<a href="hapussatuan.php?id_kategori=<?php echo $d['id_satuan']; ?>">HAPUS</a>
			<td>
		</tr>
	<?php
	}
	?>
	</table>
	</body>
	</html>
	
	<?php
	 include("footer.php");
	?>
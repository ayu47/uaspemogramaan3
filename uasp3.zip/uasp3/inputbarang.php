<?php
 include_once("koneksi.php");
 include_once("header.php");

?>

<! DOCTYPE html>
<html>
<html>
<title>ayu.com></title>
<link rel="stylesheet" type="text/css" href="bg.css">
</head>
<?php
//koneksi database
include "koneksi.php";
if(!empty($_POST['save'])){
	$nama_barang = $_POST['nama_barang'];
	$kategori_id = $_POST['kategori_id'];
	$satuan_id = $_POST['satuan_id'];

$a=mysqli_query($koneksi,"insert into barang values('','$nama_barang','$kategori_id','$satuan_id')");
if ($a)
{
	//header("location:tampilbarang.php");
}
else
{
	echo mysqli_error($koneksi);
	
}
}
$querykategori = "SELECT * FROM kategori";
$resultkategori = mysqli_query($koneksi,$querykategori);

$querysatuan = "SELECT * FROM satuan";
$resultsatuan = mysqli_query($koneksi,$querysatuan);

?>
<body>
<h2>Tambah barang<h/2>
<br/>
<a href="tampilbarang.php">KEMBALI<a/>
<br/>
<br/>
<h3>TAMBAH DATA Barang</h3>
<form method="POST">
	<table>
	<tr>
	<td>nama_barang</td>
	<td><input type="text" name="nama_barang"></td>
	</tr>
	<tr>
	<td>kategori</td>
	<td>
	<select name="kategori_id">
	<option value="">-----Pilih</option>
		<?php
			while ($datakategori=mysqli_fetch_array($resultkategori))
			{
				echo "<option value=$datakategori[id_kategori]>$datakategori[nama_kategori]</option>";
			}
		?>
	</select>
	<td>
	</tr>
	<tr>
	<td>satuan</td>
	<td><select name="satuan_id">
	<option value="">-----Pilih</option>
		<?php
			while ($datasatuan=mysqli_fetch_array($resultsatuan))
			{
				echo "<option value=$datasatuan[id_satuan]>$datasatuan[nama_satuan]</option>";
			}
		?>
	</select>
	</td>
	</tr>
	<tr>
	<td></td>
	<td><input type="submit" name="save"><td>
	</tr>
	</table>
	</form>
	</body>
	</html>

	<?php
	 include("footer.php");
	?>
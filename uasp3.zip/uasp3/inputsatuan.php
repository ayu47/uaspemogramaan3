<?php
 include_once("koneksi.php");
 include_once("header.php");

?>

<! DOCTYPE html>
<html>
<html>
<title>ayu.com></title>
<link rel="stylesheet" type="text/css" href="bg.css">
</head>
<?php
	//koneksi database
	include "koneksi.php";
	if(!empty($_POST['save']))
	{
		$nama_satuan = $_POST['nama_satuan'];
		$a = mysqli_query($koneksi,"insert into satuan values('','$nama_satuan')");
		if ($a)
		{
			//header("location:tampilsatuan.php");
		}
		else
		{
			echo mysqli_error();
		}
	}

?>
<body>
<h2>ayu.com<h/2>
<br/>
<a href="tampilsatuan.php">KEMBALI<a/>
<br/>
<br/>
<h3>TAMBAH DATA SATUAN</h3>
<form method="POST">
	<table>
	<tr>
	<td>Bentuk Satuan</td>
	<td><input type="text" name="nama_satuan"></td>
	</tr>
	<tr>
	<td></td>
	<td><input type="submit" name="save"><td>
	</tr>
	</table>
	</form>
	</body>
	</html>

	<?php
	 include("footer.php");
	?>
<?php
 include_once("koneksi.php");
 include_once("header.php");

?>

<html>
	<head>
	<title>ayu.com</title>
    <link rel="stylesheet" type="text/css" href="bg.css">
	</head>
	<body>
	<h2>ayu.com</h2>
	<br/>
	<a href="inputkategori.php">TAMBAH KATEGORI</a>
	<br/>
	<table border="1">
	<tr>
		<th>Nama Kategori</th>
		<th>OPSI</th>
	</tr>
	<?php
	include 'koneksi.php';
	$no =1;
	$data = mysqli_query($koneksi,"select * from kategori");
	while($d= mysqli_fetch_array($data)){
		?>
		<tr>
			<td><?php echo $d['nama_kategori']; ?></td>
			<td>
				<a href="editkategori.php?id_kategori=<?php echo $d['id_kategori']; ?>">EDIT</a>
				<a href="hapuskategori.php?id_kategori=<?php echo $d['id_kategori']; ?>">HAPUS</a>
			<td>
		</tr>
	<?php
	}
	?>
	</table>
	</body>
	</html>
	
	<?php
	 include("footer.php");
	?>


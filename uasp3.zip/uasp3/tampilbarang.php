<?php
 include_once("koneksi.php");
 include_once("header.php");

?>



<html>
	<head>
	<title>ayu.com</title>
    <link rel="stylesheet" type="text/css" href="bg.css">
	</head>
	<body>
	<h2>ayu.com</h2>
	<br/>
	<a href="inputbarang.php">+ TAMBAH BARANG</a>
	<br/>
	<table border="2">
	<tr>
		<th>nama_barang</th>
		<th>kategori_id</th>
		<th>satuan_id</th>
		<th>OPSI</th>
	</tr>
	<?php
	include 'koneksi.php';
	$no =1;
	$data = mysqli_query($koneksi,"select barang.id_barang,barang.nama_barang, kategori.nama_kategori, satuan.nama_satuan from barang LEFT JOIN satuan on satuan.id_satuan = barang.satuan_id LEFT JOIN kategori on kategori.id_kategori = barang.kategori_id");
	while($d= mysqli_fetch_array ($data)){
		?>
		<tr>
			<td><?php echo $d['nama_barang']; ?></td>
			<td><?php echo $d['nama_kategori']; ?></td>
			<td><?php echo $d['nama_satuan']; ?></td>
			<td>
				<a href="editbarang.php?id_barang=<?php echo $d['id_barang']; ?>">EDIT</a>
				<a href="hapusbarang.php?id_barang=<?php echo $d['id_barang']; ?>">HAPUS</a>
			<td>
		</tr>
	<?php
	}
	?>
	</table>
	</body>
	</html>

	<?php
	 include("footer.php");
	?>